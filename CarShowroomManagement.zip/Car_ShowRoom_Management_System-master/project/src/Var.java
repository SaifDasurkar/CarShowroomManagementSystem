/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Himanshu jain
 */
public class Var{
public static String User_id;
public static int CatlogKey;

}