# Car_ShowRoom_Management_System

This is my Car_ShowRoom_Management_System project.In this project I'm using Java with JDBC to Java with database.In this project Im using MySql to store my data in a database. This project is divided into 3 parts: Admin, Client and Normal-User.
In Admin mode program run with full permission on database, Admin can delete,add,check all the data from database.
In client mode program can have only partial data read/write premission, in partial program can only read/write data under that client.
In Normal-User mode no access to database user can just access catlog page to see the price of with details.
